/*
 * softPwm.h:
 *	Provide 2 channels of software driven PWM.
 *	Copyright (c) 2012 Gordon Henderson
 ***********************************************************************
 * This file is part of wiringPi:
 *	https://projects.drogon.net/raspberry-pi/wiringpi/
 *
 *    wiringPi is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as
 *    published by the Free Software Foundation, either version 3 of the
 *    License, or (at your option) any later version.
 *
 *    wiringPi is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with wiringPi.
 *    If not, see <http://www.gnu.org/licenses/>.
 ***********************************************************************
*/

#define DELAY_VIA_PWM   0
#define DELAY_VIA_PCM   1
#define LOG_LEVEL_DEBUG 	0
#define LOG_LEVEL_ERRORS 	1
#define LOG_LEVEL_DEFAULT LOG_LEVEL_DEBUG

// Default subcycle time
#define SUBCYCLE_TIME_US_DEFAULT 20000

// Subcycle minimum. We kept seeing no signals and strange behavior of the RPi
#define SUBCYCLE_TIME_US_MIN 3000

// Default pulse-width-increment-granularity
#define PULSE_WIDTH_INCREMENT_GRANULARITY_US_DEFAULT 10


#ifdef __cplusplus
extern "C" {
#endif

//PWM

extern int spwm_setup(int, int);
extern void spwm_set_loglevel(int);

extern int spwm_init_channel(int, int);
extern int spwm_clear_channel(int);
extern int spwm_clear_channel_gpio(int, int);
extern int spwm_print_channel(int);

extern int spwm_add_channel_pulse(int, int, int, int);
extern char* spwm_get_error_message(void);
extern void spwm_set_softfatal(int);

extern int spwm_is_setup(void);
extern int spwm_is_channel_initialized(int);
extern int spwm_get_pulse_incr_us(void);
extern int spwm_get_channel_subcycle_time_us(int);

extern void spwm_shutdown(void);

#ifdef __cplusplus
}
#endif
